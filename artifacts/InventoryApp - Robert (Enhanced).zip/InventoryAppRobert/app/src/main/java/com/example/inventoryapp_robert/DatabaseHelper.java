package com.example.inventoryapp_robert;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String TAG = "DatabaseHelper";

    // =====================
    // DATABASE INFO
    // =====================
    private static final String DATABASE_NAME = "inventory.db";
    private static final int DATABASE_VERSION = 3;

    // =====================
    // USER TABLE
    // =====================
    private static final String TABLE_USERS = "users";
    private static final String COL_USER_ID = "id";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";

    // =====================
    // INVENTORY TABLE
    // =====================
    private static final String TABLE_INVENTORY = "inventory";
    private static final String COL_ITEM_ID = "item_id";
    private static final String COL_ITEM_NAME = "item_name";
    private static final String COL_ITEM_QTY = "quantity";
    private static final String COL_CREATED_AT = "created_at";
    private static final String COL_UPDATED_AT = "updated_at";

    private static final String IDX_INVENTORY_NAME = "idx_inventory_item_name";
    private static final String TRG_INVENTORY_INSERT_TIMESTAMPS = "trg_inventory_insert_timestamps";
    private static final String TRG_INVENTORY_UPDATED_AT = "trg_inventory_updated_at";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // =====================
    // CREATE / UPGRADE
    // =====================
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(getCreateUsersTableSql());
        db.execSQL(getCreateInventoryTableSql());
        createInventoryNameIndex(db);
        createInventoryTimestampTriggers(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.beginTransaction();

        try {
            if (oldVersion < 3) {
                addColumnIfMissing(db, TABLE_INVENTORY, COL_CREATED_AT, "TEXT");
                addColumnIfMissing(db, TABLE_INVENTORY, COL_UPDATED_AT, "TEXT");
                backfillInventoryTimestamps(db);
                createInventoryNameIndex(db);
                createInventoryTimestampTriggers(db);
            }

            db.setTransactionSuccessful();
        } catch (SQLiteException e) {
            Log.e(TAG, "Database upgrade failed", e);
            throw e;
        } finally {
            db.endTransaction();
        }
    }

    private String getCreateUsersTableSql() {
        return "CREATE TABLE " + TABLE_USERS + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT UNIQUE NOT NULL, " +
                COL_PASSWORD + " TEXT NOT NULL)";
    }

    private String getCreateInventoryTableSql() {
        return "CREATE TABLE " + TABLE_INVENTORY + " (" +
                COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_ITEM_NAME + " TEXT NOT NULL, " +
                COL_ITEM_QTY + " INTEGER NOT NULL DEFAULT 0, " +
                COL_CREATED_AT + " TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, " +
                COL_UPDATED_AT + " TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)";
    }

    private void createInventoryNameIndex(SQLiteDatabase db) {
        db.execSQL("CREATE INDEX IF NOT EXISTS " + IDX_INVENTORY_NAME +
                " ON " + TABLE_INVENTORY + " (" + COL_ITEM_NAME + ")");
    }

    private void createInventoryTimestampTriggers(SQLiteDatabase db) {
        db.execSQL("CREATE TRIGGER IF NOT EXISTS " + TRG_INVENTORY_INSERT_TIMESTAMPS + " " +
                "AFTER INSERT ON " + TABLE_INVENTORY + " " +
                "FOR EACH ROW " +
                "WHEN NEW." + COL_CREATED_AT + " IS NULL OR NEW." + COL_UPDATED_AT + " IS NULL " +
                "BEGIN " +
                "UPDATE " + TABLE_INVENTORY + " " +
                "SET " + COL_CREATED_AT + " = IFNULL(NEW." + COL_CREATED_AT + ", CURRENT_TIMESTAMP), " +
                COL_UPDATED_AT + " = IFNULL(NEW." + COL_UPDATED_AT + ", CURRENT_TIMESTAMP) " +
                "WHERE " + COL_ITEM_ID + " = NEW." + COL_ITEM_ID + "; " +
                "END");

        db.execSQL("CREATE TRIGGER IF NOT EXISTS " + TRG_INVENTORY_UPDATED_AT + " " +
                "AFTER UPDATE ON " + TABLE_INVENTORY + " " +
                "FOR EACH ROW " +
                "WHEN NEW." + COL_UPDATED_AT + " = OLD." + COL_UPDATED_AT + " " +
                "BEGIN " +
                "UPDATE " + TABLE_INVENTORY + " " +
                "SET " + COL_UPDATED_AT + " = CURRENT_TIMESTAMP " +
                "WHERE " + COL_ITEM_ID + " = OLD." + COL_ITEM_ID + "; " +
                "END");
    }

    private void addColumnIfMissing(
            SQLiteDatabase db,
            String tableName,
            String columnName,
            String columnDefinition
    ) {
        if (!columnExists(db, tableName, columnName)) {
            db.execSQL("ALTER TABLE " + tableName + " ADD COLUMN " +
                    columnName + " " + columnDefinition);
        }
    }

    private boolean columnExists(SQLiteDatabase db, String tableName, String columnName) {
        Cursor cursor = null;

        try {
            cursor = db.rawQuery("PRAGMA table_info(" + tableName + ")", null);

            while (cursor.moveToNext()) {
                String existingColumnName = cursor.getString(cursor.getColumnIndexOrThrow("name"));

                if (columnName.equals(existingColumnName)) {
                    return true;
                }
            }
        } catch (SQLiteException e) {
            Log.e(TAG, "Column check failed for " + columnName, e);
        } finally {
            closeCursor(cursor);
        }

        return false;
    }

    private void backfillInventoryTimestamps(SQLiteDatabase db) {
        db.execSQL("UPDATE " + TABLE_INVENTORY + " " +
                "SET " + COL_CREATED_AT + " = IFNULL(" + COL_CREATED_AT + ", CURRENT_TIMESTAMP), " +
                COL_UPDATED_AT + " = IFNULL(" + COL_UPDATED_AT + ", CURRENT_TIMESTAMP) " +
                "WHERE " + COL_CREATED_AT + " IS NULL OR " + COL_UPDATED_AT + " IS NULL");
    }

    // =====================
    // USER METHODS
    // =====================

    public boolean addUser(String username, String password) {
        SQLiteDatabase db = null;

        try {
            db = getWritableDatabase();
            db.beginTransaction();

            long result = db.insert(TABLE_USERS, null, getUserValues(username, password));

            if (result != -1) {
                db.setTransactionSuccessful();
                return true;
            }
        } catch (SQLiteException e) {
            Log.e(TAG, "User could not be added", e);
        } finally {
            endTransactionSafely(db);
            closeDatabase(db);
        }

        return false;
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = null;
        Cursor cursor = null;

        try {
            db = getReadableDatabase();
            cursor = db.query(
                    TABLE_USERS,
                    new String[]{COL_USER_ID},
                    COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                    new String[]{username, password},
                    null,
                    null,
                    null
            );

            return cursor.moveToFirst();
        } catch (SQLiteException e) {
            Log.e(TAG, "User login check failed", e);
        } finally {
            closeCursor(cursor);
            closeDatabase(db);
        }

        return false;
    }

    public boolean userExists(String username) {
        SQLiteDatabase db = null;
        Cursor cursor = null;

        try {
            db = getReadableDatabase();
            cursor = db.query(
                    TABLE_USERS,
                    new String[]{COL_USER_ID},
                    COL_USERNAME + "=?",
                    new String[]{username},
                    null,
                    null,
                    null
            );

            return cursor.moveToFirst();
        } catch (SQLiteException e) {
            Log.e(TAG, "Username check failed", e);
        } finally {
            closeCursor(cursor);
            closeDatabase(db);
        }

        return false;
    }

    private ContentValues getUserValues(String username, String password) {
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);
        return values;
    }

    // =====================
    // INVENTORY METHODS
    // =====================

    public boolean addItem(String itemName, int quantity) {
        SQLiteDatabase db = null;

        try {
            db = getWritableDatabase();
            db.beginTransaction();

            long result = db.insert(TABLE_INVENTORY, null, getInventoryValues(itemName, quantity));

            if (result != -1) {
                db.setTransactionSuccessful();
                return true;
            }
        } catch (SQLiteException e) {
            Log.e(TAG, "Inventory item could not be added", e);
        } finally {
            endTransactionSafely(db);
            closeDatabase(db);
        }

        return false;
    }

    public ArrayList<InventoryItem> getAllItems() {
        return searchItemsByName("");
    }

    public ArrayList<InventoryItem> searchItemsByName(String searchText) {
        SQLiteDatabase db = null;
        Cursor cursor = null;
        ArrayList<InventoryItem> items = new ArrayList<>();

        try {
            db = getReadableDatabase();

            String selection = null;
            String[] selectionArgs = null;

            if (searchText != null && !searchText.trim().isEmpty()) {
                selection = COL_ITEM_NAME + " COLLATE NOCASE LIKE ?";
                selectionArgs = new String[]{"%" + searchText.trim() + "%"};
            }

            cursor = db.query(
                    TABLE_INVENTORY,
                    getInventoryColumns(),
                    selection,
                    selectionArgs,
                    null,
                    null,
                    COL_ITEM_NAME + " COLLATE NOCASE ASC"
            );

            while (cursor.moveToNext()) {
                items.add(getInventoryItemFromCursor(cursor));
            }
        } catch (SQLiteException e) {
            Log.e(TAG, "Inventory search failed", e);
        } finally {
            closeCursor(cursor);
            closeDatabase(db);
        }

        return items;
    }

    public boolean updateItem(int id, String itemName, int quantity) {
        SQLiteDatabase db = null;

        try {
            db = getWritableDatabase();
            db.beginTransaction();

            int rows = db.update(
                    TABLE_INVENTORY,
                    getInventoryValues(itemName, quantity),
                    COL_ITEM_ID + "=?",
                    new String[]{String.valueOf(id)}
            );

            if (rows > 0) {
                db.setTransactionSuccessful();
                return true;
            }
        } catch (SQLiteException e) {
            Log.e(TAG, "Inventory item could not be updated", e);
        } finally {
            endTransactionSafely(db);
            closeDatabase(db);
        }

        return false;
    }

    public boolean deleteItem(int id) {
        SQLiteDatabase db = null;

        try {
            db = getWritableDatabase();
            db.beginTransaction();

            int rows = db.delete(
                    TABLE_INVENTORY,
                    COL_ITEM_ID + "=?",
                    new String[]{String.valueOf(id)}
            );

            if (rows > 0) {
                db.setTransactionSuccessful();
                return true;
            }
        } catch (SQLiteException e) {
            Log.e(TAG, "Inventory item could not be deleted", e);
        } finally {
            endTransactionSafely(db);
            closeDatabase(db);
        }

        return false;
    }

    public int getInventoryItemCount() {
        return getSingleIntQuery("SELECT COUNT(*) FROM " + TABLE_INVENTORY, null);
    }

    public int getTotalInventoryQuantity() {
        return getSingleIntQuery(
                "SELECT IFNULL(SUM(" + COL_ITEM_QTY + "), 0) FROM " + TABLE_INVENTORY,
                null
        );
    }

    public int getLowInventoryCount(int threshold) {
        return getSingleIntQuery(
                "SELECT COUNT(*) FROM " + TABLE_INVENTORY + " WHERE " + COL_ITEM_QTY + " <= ?",
                new String[]{String.valueOf(threshold)}
        );
    }

    private String[] getInventoryColumns() {
        return new String[]{
                COL_ITEM_ID,
                COL_ITEM_NAME,
                COL_ITEM_QTY,
                COL_CREATED_AT,
                COL_UPDATED_AT
        };
    }

    private InventoryItem getInventoryItemFromCursor(Cursor cursor) {
        int id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ITEM_ID));
        String name = cursor.getString(cursor.getColumnIndexOrThrow(COL_ITEM_NAME));
        int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ITEM_QTY));
        String createdAt = cursor.getString(cursor.getColumnIndexOrThrow(COL_CREATED_AT));
        String updatedAt = cursor.getString(cursor.getColumnIndexOrThrow(COL_UPDATED_AT));

        return new InventoryItem(id, name, quantity, createdAt, updatedAt);
    }

    private ContentValues getInventoryValues(String itemName, int quantity) {
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, itemName);
        values.put(COL_ITEM_QTY, quantity);
        return values;
    }

    private int getSingleIntQuery(String sql, String[] selectionArgs) {
        SQLiteDatabase db = null;
        Cursor cursor = null;

        try {
            db = getReadableDatabase();
            cursor = db.rawQuery(sql, selectionArgs);

            if (cursor.moveToFirst()) {
                return cursor.getInt(0);
            }
        } catch (SQLiteException e) {
            Log.e(TAG, "Aggregate query failed: " + sql, e);
        } finally {
            closeCursor(cursor);
            closeDatabase(db);
        }

        return 0;
    }

    private void endTransactionSafely(SQLiteDatabase db) {
        if (db != null && db.inTransaction()) {
            db.endTransaction();
        }
    }

    private void closeCursor(Cursor cursor) {
        if (cursor != null && !cursor.isClosed()) {
            cursor.close();
        }
    }

    private void closeDatabase(SQLiteDatabase db) {
        if (db != null && db.isOpen()) {
            db.close();
        }
    }
}
