package com.example.inventoryapp_robert;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Comparator;

public class InventoryActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;
    private static final String SORT_NAME_ASC = "Name (A-Z)";
    private static final String SORT_NAME_DESC = "Name (Z-A)";
    private static final String SORT_QTY_ASC = "Quantity (Low to High)";
    private static final String SORT_QTY_DESC = "Quantity (High to Low)";
    private static final String[] SORT_OPTIONS = {
            SORT_NAME_ASC,
            SORT_NAME_DESC,
            SORT_QTY_ASC,
            SORT_QTY_DESC
    };

    DatabaseHelper databaseHelper;
    EditText editItemName, editQuantity, editSearchInventory;
    Button buttonAddItem, buttonSms;
    Spinner spinnerSortInventory;
    ListView listInventory;

    ArrayList<InventoryItem> inventoryItems;
    ArrayList<InventoryItem> displayedInventoryItems;
    ArrayAdapter<InventoryItem> adapter;
    String currentSortOption = SORT_NAME_ASC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        databaseHelper = new DatabaseHelper(this);

        editItemName = findViewById(R.id.editItemName);
        editQuantity = findViewById(R.id.editQuantity);
        editSearchInventory = findViewById(R.id.editSearchInventory);
        buttonAddItem = findViewById(R.id.buttonAddItem);
        buttonSms = findViewById(R.id.buttonSms);
        spinnerSortInventory = findViewById(R.id.spinnerSortInventory);
        listInventory = findViewById(R.id.listInventory);

        inventoryItems = new ArrayList<>();
        displayedInventoryItems = new ArrayList<>();

        adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                displayedInventoryItems
        );

        listInventory.setAdapter(adapter);
        setupSearchAndSort();

        loadInventory();

        buttonAddItem.setOnClickListener(v -> addItem());

        // Edit item when clicked
        listInventory.setOnItemClickListener((parent, view, position, id) -> {
            InventoryItem selectedItem = displayedInventoryItems.get(position);
            showEditItemDialog(selectedItem);
        });

        // Delete item when long-clicked
        listInventory.setOnItemLongClickListener((parent, view, position, id) -> {
            InventoryItem selectedItem = displayedInventoryItems.get(position);
            showDeleteItemDialog(selectedItem);
            return true;
        });

        // SMS button
        buttonSms.setOnClickListener(v -> checkSmsPermission());
    }

    // =====================
    // INVENTORY METHODS
    // =====================

    private void setupSearchAndSort() {
        ArrayAdapter<String> sortAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                SORT_OPTIONS
        );
        sortAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerSortInventory.setAdapter(sortAdapter);

        spinnerSortInventory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                currentSortOption = SORT_OPTIONS[position];
                applySortAndDisplay();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                currentSortOption = SORT_NAME_ASC;
                applySortAndDisplay();
            }
        });

        editSearchInventory.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                loadInventory();
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    private void addItem() {
        String name = editItemName.getText().toString().trim();
        String qtyStr = editQuantity.getText().toString().trim();

        if (name.isEmpty()) {
            editItemName.setError("Item name is required");
            return;
        }

        Integer quantity = getValidQuantity(qtyStr, editQuantity);
        if (quantity == null) {
            return;
        }

        boolean itemAdded = databaseHelper.addItem(name, quantity);
        if (!itemAdded) {
            Toast.makeText(this, "Item could not be added", Toast.LENGTH_SHORT).show();
            return;
        }

        editItemName.setText("");
        editQuantity.setText("");

        loadInventory();
        Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();
    }

    private void showEditItemDialog(InventoryItem item) {
        int itemId = item.getId();
        String currentName = item.getName();
        int currentQuantity = item.getQuantity();

        LinearLayout dialogLayout = new LinearLayout(this);
        dialogLayout.setOrientation(LinearLayout.VERTICAL);
        int padding = (int) (20 * getResources().getDisplayMetrics().density);
        dialogLayout.setPadding(padding, padding / 2, padding, 0);

        EditText editName = new EditText(this);
        editName.setHint("Item Name");
        editName.setSingleLine(true);
        editName.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        editName.setText(currentName);
        dialogLayout.addView(editName);

        EditText editQty = new EditText(this);
        editQty.setHint("Quantity");
        editQty.setSingleLine(true);
        editQty.setInputType(InputType.TYPE_CLASS_NUMBER);
        editQty.setText(String.valueOf(currentQuantity));
        dialogLayout.addView(editQty);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Edit Inventory Item")
                .setView(dialogLayout)
                .setPositiveButton("Save", null)
                .setNeutralButton("Delete", null)
                .setNegativeButton("Cancel", null)
                .create();

        dialog.setOnShowListener(dialogInterface -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String updatedName = editName.getText().toString().trim();
                String updatedQtyStr = editQty.getText().toString().trim();

                if (updatedName.isEmpty()) {
                    editName.setError("Item name is required");
                    return;
                }

                Integer updatedQuantity = getValidQuantity(updatedQtyStr, editQty);
                if (updatedQuantity == null) {
                    return;
                }

                boolean itemUpdated = databaseHelper.updateItem(
                        itemId,
                        updatedName,
                        updatedQuantity
                );

                if (itemUpdated) {
                    item.setName(updatedName);
                    item.setQuantity(updatedQuantity);
                    loadInventory();
                    Toast.makeText(this, "Item updated", Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                } else {
                    Toast.makeText(this, "Item could not be updated", Toast.LENGTH_SHORT).show();
                }
            });

            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                dialog.dismiss();
                confirmDeleteItem(itemId, currentName);
            });
        });

        dialog.show();
    }

    private void showDeleteItemDialog(InventoryItem item) {
        confirmDeleteItem(item.getId(), item.getName());
    }

    private void confirmDeleteItem(int itemId, String itemName) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Inventory Item")
                .setMessage("Delete " + itemName + "?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    boolean itemDeleted = databaseHelper.deleteItem(itemId);

                    if (itemDeleted) {
                        loadInventory();
                        Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Item could not be deleted", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private Integer getValidQuantity(String qtyStr, EditText quantityInput) {
        if (qtyStr.isEmpty()) {
            quantityInput.setError("Quantity is required");
            return null;
        }

        try {
            int quantity = Integer.parseInt(qtyStr);

            if (quantity < 0) {
                quantityInput.setError("Quantity cannot be negative");
                return null;
            }

            return quantity;
        } catch (NumberFormatException e) {
            quantityInput.setError("Enter a valid quantity");
            return null;
        }
    }

    private void loadInventory() {
        inventoryItems.clear();
        inventoryItems.addAll(databaseHelper.searchItemsByName(getCurrentSearchText()));
        applySortAndDisplay();
    }

    private String getCurrentSearchText() {
        return editSearchInventory.getText().toString().trim();
    }

    private void applySortAndDisplay() {
        displayedInventoryItems.clear();
        displayedInventoryItems.addAll(inventoryItems);

        sortDisplayedInventoryItems();
        adapter.notifyDataSetChanged();
    }

    private void sortDisplayedInventoryItems() {
        Comparator<InventoryItem> comparator;

        switch (currentSortOption) {
            case SORT_NAME_DESC:
                comparator = (first, second) -> compareNames(second, first);
                break;
            case SORT_QTY_ASC:
                comparator = this::compareQuantities;
                break;
            case SORT_QTY_DESC:
                comparator = (first, second) -> compareQuantities(second, first);
                break;
            case SORT_NAME_ASC:
            default:
                comparator = this::compareNames;
                break;
        }

        displayedInventoryItems.sort(comparator);
    }

    private int compareNames(InventoryItem first, InventoryItem second) {
        int result = first.getName().compareToIgnoreCase(second.getName());

        if (result == 0) {
            result = Integer.compare(first.getId(), second.getId());
        }

        return result;
    }

    private int compareQuantities(InventoryItem first, InventoryItem second) {
        int result = Integer.compare(first.getQuantity(), second.getQuantity());

        if (result == 0) {
            result = compareNames(first, second);
        }

        return result;
    }

    // =====================
    // SMS PERMISSION + SEND
    // =====================

    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED) {

            sendSmsAlert();

        } else {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                sendSmsAlert();

            } else {
                Toast.makeText(
                        this,
                        "SMS permission denied. App will continue without notifications.",
                        Toast.LENGTH_LONG
                ).show();
            }
        }
    }

    private void sendSmsAlert() {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(
                    "19197489495",   // Emulator-safe test number
                    null,
                    "Inventory Alert: Check your inventory levels.",
                    null,
                    null
            );

            Toast.makeText(this, "SMS alert sent", Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show();
        }
    }
}
