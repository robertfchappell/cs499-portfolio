package com.example.inventoryapp_robert;

public class InventoryItem {

    private final int id;
    private String name;
    private int quantity;
    private String createdAt;
    private String updatedAt;

    public InventoryItem(int id, String name, int quantity) {
        this(id, name, quantity, "", "");
    }

    public InventoryItem(int id, String name, int quantity, String createdAt, String updatedAt) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public String toString() {
        return name + " - Qty: " + quantity;
    }
}
